package ScreenStudent;

import ConnectionDB.ConnMySql;
import ScreenAdmin.addFaculty;
import Table.StudentLesson;
import Table.StudentPoints;

import javax.swing.table.DefaultTableModel;
import java.util.List;

public class ScreenOpened extends javax.swing.JDialog {

    private final ConnMySql conn;

    public ScreenOpened(java.awt.Frame parent, boolean modal, int idStudent) {
        super(parent, modal);
        initComponents();
        conn = new ConnectionDB.ConnMySql();
        FillTheTable(conn.GetStudentLessonByidStudent(idStudent));
    }
//we take lessons which are isActive=1, but passed=0, and fill them to this table
    public void FillTheTable(List<StudentLesson> list) {
        DefaultTableModel tmodel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

        };
        tmodel.addColumn("lekcija");

        jTableOpened.setModel(tmodel);

        for (StudentLesson stule : list) {
            tmodel.insertRow(jTableOpened.getRowCount(), new Object[]{
                conn.GetLessonByidLesson(stule.idlekcija).ime
            });
        }
        jTableOpened.setModel(tmodel);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableOpened = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(230, 226, 226));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTableOpened.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Lekcija"
            }
        ));
        jScrollPane1.setViewportView(jTableOpened);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableOpened;
    // End of variables declaration//GEN-END:variables

    public static class ScreenTranscript extends javax.swing.JDialog {

        private final ConnMySql conn;
        private final List<StudentPoints> ListOfPoints;

        public ScreenTranscript(java.awt.Frame parent, boolean modal, int idStudent) {
            super(parent, modal);
            initComponents();
            conn = new ConnMySql();
            ListOfPoints = conn.GetStudentPointsByidStudent(idStudent);
            FillTheTable(ListOfPoints);
            GetCreditsAndGPA();
        }
        //we take data from mysql which are not active and passed, or couldnt passed 60
        //but we calculate gpa and total credit for which lesson >=60
        public void GetCreditsAndGPA() { //get gpa and credit and calculate total
            int Credit = 0;
            int Points = 0;
            int FinalGPA = 0;

            for (StudentPoints lsp : ListOfPoints) {
                if (lsp.GetTotal() >= 60) {
                    Credit = Credit + conn.GetLessonByidLesson(lsp.idlekcija).poen;
                    Points = Points + conn.GetLessonByidLesson(lsp.idlekcija).poen * lsp.GetTotal();
                }
            }
            if (Credit > 0 && Points > 0) {
                FinalGPA = Points / Credit;
            }
            jTextFieldTotalCredit.setText("" + Credit);
            jTextFieldGpa.setText("" + FinalGPA);
        }

        public void FillTheTable(List<StudentPoints> list) { //get information from database and fill it to table
            DefaultTableModel tmodel = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            tmodel.addColumn("Lekcija");
            tmodel.addColumn("Bodovi");
            tmodel.addColumn("Ukupno");

            jTableStudentPoints.setModel(tmodel);

            for (StudentPoints stupo : list) {  // set data for each columns
                tmodel.insertRow(jTableStudentPoints.getRowCount(), new Object[]{
                        conn.GetLessonByidLesson(stupo.idlekcija).ime,
                        conn.GetLessonByidLesson(stupo.idlekcija).poen,
                        stupo.ukupno
                });
            }
        }

        @SuppressWarnings("unchecked")
        // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
        private void initComponents() {

            jPanel1 = new javax.swing.JPanel();
            jScrollPane1 = new javax.swing.JScrollPane();
            jTableStudentPoints = new javax.swing.JTable();
            jLabelTotalCredit = new javax.swing.JLabel();
            jLabelGpa = new javax.swing.JLabel();
            jTextFieldTotalCredit = new javax.swing.JTextField();
            jTextFieldGpa = new javax.swing.JTextField();

            setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
            setResizable(false);

            jPanel1.setBackground(new java.awt.Color(230, 226, 226));
            jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

            jTableStudentPoints.setModel(new DefaultTableModel(
                new Object [][] {

                },
                new String [] {
                    "Lekcija", "Bodovi", "Ukupno"
                }
            ));
            jScrollPane1.setViewportView(jTableStudentPoints);
            if (jTableStudentPoints.getColumnModel().getColumnCount() > 0) {
                jTableStudentPoints.getColumnModel().getColumn(1).setMinWidth(70);
                jTableStudentPoints.getColumnModel().getColumn(1).setPreferredWidth(70);
                jTableStudentPoints.getColumnModel().getColumn(1).setMaxWidth(70);
                jTableStudentPoints.getColumnModel().getColumn(2).setMinWidth(70);
                jTableStudentPoints.getColumnModel().getColumn(2).setPreferredWidth(70);
                jTableStudentPoints.getColumnModel().getColumn(2).setMaxWidth(70);
            }

            jLabelTotalCredit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
            jLabelTotalCredit.setForeground(new java.awt.Color(10, 10, 61));
            jLabelTotalCredit.setText("Ukupno bodova:");

            jLabelGpa.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
            jLabelGpa.setForeground(new java.awt.Color(10, 10, 61));
            jLabelGpa.setText(" Prosjek:");

            jTextFieldTotalCredit.setBorder(javax.swing.BorderFactory.createEtchedBorder());
            jTextFieldTotalCredit.setEnabled(false);
            jTextFieldTotalCredit.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jTextFieldTotalCreditActionPerformed(evt);
                }
            });

            jTextFieldGpa.setBorder(javax.swing.BorderFactory.createEtchedBorder());
            jTextFieldGpa.setEnabled(false);
            jTextFieldGpa.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jTextFieldGpaActionPerformed(evt);
                }
            });

            javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabelTotalCredit)
                        .addComponent(jLabelGpa))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jTextFieldTotalCredit)
                        .addComponent(jTextFieldGpa, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(25, 25, 25))
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap(33, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelTotalCredit)
                        .addComponent(jTextFieldTotalCredit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabelGpa)
                        .addComponent(jTextFieldGpa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(26, 26, 26))
            );

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            );

            pack();
            setLocationRelativeTo(null);
        }// </editor-fold>//GEN-END:initComponents

        private void jTextFieldTotalCreditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldTotalCreditActionPerformed

        }//GEN-LAST:event_jTextFieldTotalCreditActionPerformed

        private void jTextFieldGpaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldGpaActionPerformed

        }//GEN-LAST:event_jTextFieldGpaActionPerformed
        public static void main(String args[]) {
            /* Set the Nimbus look and feel */
            //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
            /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
             * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
             */
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ClassNotFoundException ex) {
                java.util.logging.Logger.getLogger(addFaculty.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (InstantiationException ex) {
                java.util.logging.Logger.getLogger(addFaculty.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                java.util.logging.Logger.getLogger(addFaculty.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                java.util.logging.Logger.getLogger(addFaculty.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
            //</editor-fold>

            /* Create and display the dialog */
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {
                    addFaculty dialog = new addFaculty(new javax.swing.JFrame(), true);
                    dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                        @Override
                        public void windowClosing(java.awt.event.WindowEvent e) {
                            System.exit(0);
                        }
                    });
                    dialog.setVisible(true);
                }
            });
        }

        // Variables declaration - do not modify//GEN-BEGIN:variables
        private javax.swing.JLabel jLabelGpa;
        private javax.swing.JLabel jLabelTotalCredit;
        private javax.swing.JPanel jPanel1;
        private javax.swing.JScrollPane jScrollPane1;
        private javax.swing.JTable jTableStudentPoints;
        private javax.swing.JTextField jTextFieldGpa;
        private javax.swing.JTextField jTextFieldTotalCredit;
        // End of variables declaration//GEN-END:variables
    }
}
