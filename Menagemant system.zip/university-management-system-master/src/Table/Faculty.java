package Table;

public class Faculty {

    public int idodsjek;
    public String ime;

    public Faculty() {

    }

    public Faculty(int idodsjek, String ime) {
        this.idodsjek = idodsjek;
        this.ime = ime;

    }
}
