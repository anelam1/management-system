package Table;

public class Teacher {

    public int idProf;
    public String ime;
    public String prez;
    public String dat;
    public String broj;

    public Teacher() {

    }

    public Teacher(int idProf, String ime, String prez, String dat, String broj) {
        this.idProf = idProf;
        this.ime = ime;
        this.prez = prez;
        this.dat= dat;
        this.broj = broj;
    }
}
