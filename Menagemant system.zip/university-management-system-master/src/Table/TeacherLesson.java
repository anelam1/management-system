package Table;

public class TeacherLesson {

    public int idProfLekcija;
    public int idProf;
    public int idlekcija;

    public TeacherLesson() {
    }

    public TeacherLesson(int idProfLekcija, int idProf, int idlekcija) {
        this.idProfLekcija = idProfLekcija;
        this.idProf = idProf;
        this.idlekcija = idlekcija;
    }
}
