package Table;

public class Lesson {

    public int idlekcija;
    public String ime;
    public String kod;
    public int idProf;
    public int idodsjek;
    public int poen;

    public Lesson() {

    }

    public Lesson(int idlekcija, String ime, String kod, int idProf, int idodsjek, int poen) {
        this.idlekcija = idlekcija;
        this.ime = ime;
        this.kod = kod;
        this.idProf = idProf;
        this.idodsjek = idodsjek;
        this.poen = poen;
    }
}
