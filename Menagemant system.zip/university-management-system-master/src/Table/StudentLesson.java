package Table;

public class StudentLesson {

    public int idStudentLekcija;
    public int idStudent;
    public int idlekcija;
    public int isActive;
    public int isPassed;

    public StudentLesson() {
    }

    public StudentLesson(int idStudentLekcija, int idStudent, int idlekcija, int isActive, int isPassed) {
        this.idStudentLekcija = idStudentLekcija;
        this.idStudent = idStudent;
        this.idlekcija = idlekcija;
        this.isActive = isActive;
        this.isPassed = isPassed;
    }

}
