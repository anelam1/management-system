package Table;

public class Student {

    public int idStudent;
    public String ime;
    public String prez;
    public String dat;
    public int idodsjek;
    public int idmaster;
    public String sifra;

    public Student() {

    }

    public Student(int idStudent, String ime, String prez, String dat, int idodsjek, int idmaster, String sifra) {
        this.idStudent = idStudent;
        this.ime = ime;
        this.prez = prez;
        this.dat = dat;
        this.idodsjek = idodsjek;
        this.idmaster = idmaster;
        this.sifra = sifra;
    }

    public String GetFullName() {
        return ime + " " + prez;
    }
}
