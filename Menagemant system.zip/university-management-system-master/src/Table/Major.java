package Table;

public class Major {

    public int idmaster;
    public String ime;

    public Major() {

    }

    public Major(int idmaster, String ime) {
        this.idmaster = idmaster;
        this.ime = ime;

    }
}
