package Table;

public class StudentPoints {

    public int idStudentBodovi;
    public int idStudent;
    public int idlekcija;
    public int semestar;
    public int kviz;
    public int aktivnost;
    public int finalno;
    public int ukupno;

    public StudentPoints() {
    }

    public int GetTotal() {
        return semestar+ kviz + finalno + aktivnost;
    }

    public StudentPoints(int idStudentBodovi, int idStudent, int idlekcija, int semestar, int kviz, int aktivnost, int finalno, int ukupno) {
        this.idStudentBodovi = idStudentBodovi;
        this.idStudent = idStudent;
        this.idlekcija = idlekcija;
        this.semestar = semestar;
        this.kviz = kviz;
        this.aktivnost = aktivnost;
        this.finalno = finalno;
        this.ukupno= ukupno;

    }

}
