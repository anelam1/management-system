package ConnectionDB;

import Table.Faculty;
import Table.Lesson;
import Table.Major;
import Table.Student;
import Table.StudentLesson;
import Table.StudentPoints;
import Table.TeacherLesson;
import Table.Teacher;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ConnMySql {

    private Connection connection;
    private Statement st;
    private ResultSet rs;

    //CONNECTION TO MYSQL
    public ConnMySql() {
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/sims?useSSL=false&serverTimezone=UTC";
            String user = "root";
            String pasword = "Anela2609";
            connection = DriverManager.getConnection(url, user, pasword);
            st = connection.createStatement();
        } catch (Exception e) {
            System.out.println("Error connection" + e);
        }
    }

//INSERT FOR STUDENT
    public void InsUpStudent(Student stu) {
        try {
            String SqlEmri = "";
            if (stu.idStudent == 0) {
                SqlEmri = "insert into student(ime,prez,dat,idodsjek,idmaster,sifra)values(?,?,?,?,?,?)";
            } else {
                SqlEmri = "update student set ime=?,prez=?,dat=?,idodsjek=?,idmaster=?,sifra=? where idStudent=?";
            }
            PreparedStatement prSql = connection.prepareStatement(SqlEmri);
            prSql.setString(1, stu.ime);
            prSql.setString(2, stu.prez);
            prSql.setString(3, stu.dat);
            prSql.setInt(4, stu.idodsjek);
            prSql.setInt(5, stu.idmaster);
            prSql.setString(6, stu.sifra);
            if (stu.idStudent != 0) {
                prSql.setInt(7, stu.idStudent);
            }
            prSql.execute();
        } catch (Exception e) {
            System.out.println("Error insertStudent: " + e);
        }
    }

// INSERT TEACHER
    public void InsUpTeacher(Teacher teac) {
        try {
            String SqlEmri = "";
            if (teac.idProf == 0) {
                SqlEmri = "insert into teacher(ime,prez,dat,broj)values(?,?,?,?)";
            } else {
                SqlEmri = "update teacher set ime=?,prez=?,dat=?,broj=? where idProf=?";
            }
            PreparedStatement prSql = connection.prepareStatement(SqlEmri);
            prSql.setString(1, teac.ime);
            prSql.setString(2, teac.prez);
            prSql.setString(3, teac.dat);
            prSql.setString(4, teac.broj);
            if (teac.idProf != 0) {
                prSql.setInt(5, teac.idProf);
            }
            prSql.execute();
        } catch (Exception e) {
            System.out.println("Error insertTeacher: " + e);
        }

    }

    // INSERT FACULTY
    public void InsUpFaculty(Faculty fac) {
        try {
            String SqlEmri = "";
            if (fac.idodsjek == 0) {
                SqlEmri = "insert into faculty(ime)values(?)";
            } else {
                SqlEmri = "update faculty set ime=? where idodsjek=?";
            }
            PreparedStatement prSql = connection.prepareStatement(SqlEmri);
            prSql.setString(1, fac.ime);
            if (fac.idodsjek != 0) {
                prSql.setInt(2, fac.idodsjek);
            }
            prSql.execute();
        } catch (Exception e) {
            System.out.println("Error insertFaculty: " + e);
        }
    }

    // INSERT MAJOR
    public void InsUpMajor(Major maj) {
        try {
            String SqlEmri = "";
            if (maj.idmaster == 0) {
                SqlEmri = "insert into major(ime)values(?)";
            } else {
                SqlEmri = "update major set ime=? where idmaster=?";
            }
            PreparedStatement prSql = connection.prepareStatement(SqlEmri);
            prSql.setString(1, maj.ime);
            if (maj.idmaster != 0) {
                prSql.setInt(22, maj.idmaster);
            }
            prSql.execute();
        } catch (Exception e) {
            System.out.println("Error insertMajor: " + e);
        }
    }

    // INSERT LESSON
    public void InsUpLesson(Lesson les) {
        try {
            String SqlEmri = "";
            if (les.idlekcija == 0) {
                SqlEmri = "insert into lesson(ime,kod,idodsjek,idProf,poen)values(?,?,?,?,?)";
            } else {
                SqlEmri = "update lesson set ime=?,kod=?,idodsjek=?,idProf=?,poen=? where idlekcija=?";
            }
            PreparedStatement prSql = connection.prepareStatement(SqlEmri);
            prSql.setString(1, les.ime);
            prSql.setString(2, les.kod);
            prSql.setInt(3, les.idodsjek);
            prSql.setInt(4, les.idProf);
            prSql.setInt(5, les.poen);

            if (les.idlekcija != 0) {
                prSql.setInt(6, les.idlekcija);
            }
            prSql.execute();
        } catch (Exception e) {
            System.out.println("Error insertLesson: " + e);
        }
    }

    // INSERT StudentLesson
    public void InsUpStudentLesson(StudentLesson stule) {
        try {
            String SqlEmri = "";
            if (stule.idStudentLekcija == 0) {
                SqlEmri = "insert into studentlesson(idStudent,idlekcija,isActive,isPassed)values(?,?,?,?)";
            } else {
                SqlEmri = "update studentlesson set idStudent=?,idlekcija=?,isActive=?,isPassed=? where idStudentLekcija=?";
            }
            PreparedStatement prSql = connection.prepareStatement(SqlEmri);
            prSql.setInt(1, stule.idStudent);
            prSql.setInt(2, stule.idlekcija);
            prSql.setInt(3, stule.isActive);
            prSql.setInt(4, stule.isPassed);

            if (stule.idStudentLekcija != 0) {
                prSql.setInt(5, stule.idStudentLekcija);
            }
            prSql.execute();
        } catch (Exception e) {
            System.out.println("Error insertStudentLesson: " + e);
        }
    }

    // INSERT StudentPoints
    public void InsUpStudentPoints(StudentPoints stupo) {
        try {
            String SqlEmri = "";
            if (stupo.idStudentBodovi == 0) {
                SqlEmri = "insert into studentpoints(idStudent,idlekcija,semestar,kviz,aktivnost,finalno,ukupno)values(?,?,?,?,?,?,?)";
            } else {
                SqlEmri = "update studentpoints set idStudent=?,idlecija,semestar=?,kviz=?,aktivnost=?,finalno=?,ukupno=? where idStudentBodovi=?";
            }
            PreparedStatement prSql = connection.prepareStatement(SqlEmri);
            prSql.setInt(1, stupo.idStudent);
            prSql.setInt(2, stupo.idlekcija);
            prSql.setInt(3, stupo.semestar);
            prSql.setInt(4, stupo.kviz);
            prSql.setInt(5, stupo.aktivnost);
            prSql.setInt(6, stupo.finalno);
            prSql.setInt(7, stupo.GetTotal());

            if (stupo.idStudentBodovi != 0) {
                prSql.setInt(8, stupo.idStudentBodovi);
            }
            prSql.execute();
        } catch (Exception e) {
            System.out.println("Error insertStudentPoints: " + e);
        }
    }

    // INSERT TeacherLesson
    public void InsUpTeacherLesson(TeacherLesson tele) {
        try {
            String SqlEmri = "";
            if (tele.idProfLekcija == 0) {
                SqlEmri = "insert into teacherlesson(idProf,idlekcija)values(?,?)";
            } else {
                SqlEmri = "update teacherlesson set idProf=?,idlekcija=? where idProfLekcija=?";
            }
            PreparedStatement prSql = connection.prepareStatement(SqlEmri);
            prSql.setInt(1, tele.idProf);
            prSql.setInt(2, tele.idlekcija);

            if (tele.idProfLekcija != 0) {
                prSql.setInt(3, tele.idProfLekcija);
            }
            prSql.execute();
        } catch (Exception e) {
            System.out.println("Error insertTeacherLesson: " + e);
        }
    }

//SQLEMRI FOR STUDENT
    private List<Student> AllStudent(String where) {
        try {
            String SqlEmri = "Select * from student " + where;
            List<Student> list = new ArrayList<>();
            rs = st.executeQuery(SqlEmri);
            while (rs.next()) {
                list.add(new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getInt(6), rs.getString(7)));
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error getAllStudent: " + e);
            return null;
        }
    }

    //SQLEMRI FOR TEACHER
    public List<Teacher> AllTeacher(String where) {
        try {
            String SqlEmri = "Select * from teacher " + where;
            List<Teacher> list = new ArrayList<>();
            rs = st.executeQuery(SqlEmri);
            while (rs.next()) {
                list.add(new Teacher(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error getAllTeacher: " + e);
            return null;
        }
    }

    //SQLEMRI FOR FACULTY
    public List<Faculty> AllFaculty(String where) {
        try {
            String SqlEmri = "Select * from faculty " + where;
            List<Faculty> list = new ArrayList<>();
            rs = st.executeQuery(SqlEmri);
            while (rs.next()) {
                list.add(new Faculty(rs.getInt(1), rs.getString(2)));
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error getAllFaculty: " + e);
            return null;
        }
    }

    //SQLEMRI FOR MAJOR
    public List<Major> AllMajor(String where) {
        try {
            String SqlEmri = "Select * from Major " + where;
            List<Major> list = new ArrayList<>();
            rs = st.executeQuery(SqlEmri);
            while (rs.next()) {
                list.add(new Major(rs.getInt(1), rs.getString(2)));
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error getAllMajor: " + e);
            return null;
        }
    }

//SQLEMRI FOR LESSON
    public List<Lesson> AllLesson(String where) {
        try {
            String SqlEmri = "Select * from lesson " + where;
            List<Lesson> list = new ArrayList<>();
            rs = st.executeQuery(SqlEmri);
            while (rs.next()) {
                list.add(new Lesson(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getInt(6)));
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error getAllLesson: " + e);
            return null;
        }
    }

    //SQLEMRI FOR STUDENTLESSON
    public List<StudentLesson> AllStudentLesson(String where) {
        try {
            String SqlEmri = "Select * from studentlesson " + where;
            List<StudentLesson> list = new ArrayList<>();
            rs = st.executeQuery(SqlEmri);
            while (rs.next()) {
                list.add(new StudentLesson(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5)));
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error getAllStudentLesson: " + e);
            return null;
        }
    }
    //SQLEMRI FOR StudentPoints

    public List<StudentPoints> AllStudentPoints(String where) {
        try {
            String SqlEmri = "Select * from studentpoints " + where;
            List<StudentPoints> list = new ArrayList<>();
            rs = st.executeQuery(SqlEmri);
            while (rs.next()) {
                list.add(new StudentPoints(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getInt(8)));
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error getAllStudentPoints: " + e);
            return null;
        }
    }
    //SQLEMRI FOR TeacherLESSON

    public List<TeacherLesson> AllTeacherLesson(String where) {
        try {
            String SqlEmri = "Select * from teacherlesson " + where;
            List<TeacherLesson> list = new ArrayList<>();
            rs = st.executeQuery(SqlEmri);
            while (rs.next()) {
                list.add(new TeacherLesson(rs.getInt(1), rs.getInt(2), rs.getInt(3)));
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error getAllTeacherLesson: " + e);
            return null;
        }
    }

//GET INFORMATION FOR STUDENT 
    public List<Student> GetAllStudent() {
        return AllStudent("");
    }

    public Student GetStudentByName(String ime) {
        return AllStudent("where ime = '" + ime + "'").get(0);
    }

    public Student GetStudentByLogin(int idStudent, String sifra) {
        return AllStudent("where idStudent = '" + idStudent + "' and Password=" + sifra).get(0);
    }

    public Student GetStudentBySurname(String prez) {
        return AllStudent("where prez = '" + prez + "'").get(0);
    }

    public Student GetStudentByBirth(String dat) {
        return AllStudent("where dat = '" + dat + "'").get(0);
    }

    public Student GetStudentByidFaculty(int idodsjek) {
        return AllStudent("where idodsjek = " + idodsjek).get(0);
    }

    public Student GetStudentByidMajor(int idmaster) {
        return AllStudent("where idmaster = " + idmaster).get(0);
    }

    public Student GetStudentByidStudent(int idStudent) {
        return AllStudent("where idStudent = " + idStudent).get(0);
    }

//GET INFORMATION FOR TEACHER 
    public List<Teacher> GetAllTeacher() {
        return AllTeacher("");
    }

    public Teacher GetTeacherByName(String ime) {
        return AllTeacher("where ime = '" + ime + "'").get(0);
    }

    public Teacher GetTeacherBySurname(String prez) {
        return AllTeacher("where prez = '" + prez + "'").get(0);
    }

    public Teacher GetTeacherBirth(String dat) {
        return AllTeacher("where dat = '" + dat + "'").get(0);
    }

    public Teacher GetTeacherByNumber(String broj) {
        return AllTeacher("where broj = '" + broj + "'").get(0);
    }

    public Teacher GetTeacherbyidTeacher(int idProf) {
        return AllTeacher("where idProf = " + idProf).get(0);
    }

//GET INFORMATIN FOR LESSON
    public List<Lesson> GetAllLesson() {
        return AllLesson("");
    }

    public Lesson GetLessonByName(String ime) {
        return AllLesson("where ime = '" + ime + "'").get(0);
    }

    public Lesson GetLessonByCode(String kod) {
        return AllLesson("where kod = '" + kod + "'").get(0);
    }

    public Lesson GetLessonByidTeacher(int idProf) {
        return AllLesson("where idProf = " + idProf).get(0);
    }

    public Lesson GetLessonByidFaculty(int idodsjek) {
        return AllLesson("where idodsjek = " + idodsjek).get(0);
    }

    public Lesson GetLessonByCredit(int poen) {
        return AllLesson("where poen = " + poen).get(0);
    }

    public Lesson GetLessonByidLesson(int idlekcija) {
        return AllLesson("where idlekcija = " + idlekcija).get(0);
    }

//GET INFORMATIN FOR FACULTY
    public List<Faculty> GetAllFaculty() {
        return AllFaculty("");
    }

    public Faculty GetFacultyByName(String ime) {
        return AllFaculty("where ime = '" + ime + "'").get(0);
    }

    public Faculty GetFacultyByidFaculty(int idodsjek) {
        return AllFaculty("where idodsjek = " + idodsjek).get(0);
    }

//GET INFORMATIN FOR Major
    public List<Major> GetAllMajor() {
        return AllMajor("");
    }

    public Major GetMajorByName(String ime) {
        return AllMajor("where ime = '" + ime + "'").get(0);
    }

    public Major GetMajorByidMajor(int idmaster) {
        return AllMajor("where idmaster = " + idmaster).get(0);
    }

    //GET INFORMATIN FOR STUDENTLESSON
    public List<StudentLesson> GetAllStudentLesson() {
        return AllStudentLesson("");
    }

    public List<StudentLesson> GetStudentLessonByidStudent(int idStudent) {
        return AllStudentLesson("where isActive=1 and isPassed=0 and idStudent = " + idStudent);
    }

    public List<Lesson> getLessonsForStudent(int idStudent) {
        return AllLesson("where lesson.idlekcija not in(select stule.idlekcija from studentlesson stule where (stule.isActive=1 or stule.isPassed=1) and stule.idStudent = " + idStudent + ")");
    }

    public StudentLesson GetStudentLessonByidLesson(int idlekcija) {
        return AllStudentLesson("where idlekcija = " + idlekcija).get(0);
    }

    public StudentLesson GetStudentLessonByidStudentLesson(int idStudentLekcija) {
        return AllStudentLesson("where idStudentLekcija = " + idStudentLekcija).get(0);
    }

    //GET INFORMATIN FOR TeacherLESSON
    public List<TeacherLesson> GetAllTeacherLesson() {
        return AllTeacherLesson("");
    }

    public TeacherLesson GetTeacherLessonByidTeacher(int idProf) {
        return AllTeacherLesson("where idProf = " + idProf).get(0);
    }

    public TeacherLesson GetTeacherLessonByidLesson(int idlekcija) {
        return AllTeacherLesson("where idlekcija = " + idlekcija).get(0);
    }

    public TeacherLesson GetTeacherLessonByidTeacherLesson(int idProfLekcija) {
        return AllTeacherLesson("where idProfLekcija = " + idProfLekcija).get(0);
    }

    //GET INFORMATIN FOR STUDENTPOINTS
    public List<StudentPoints> GetAllStudentPoints() {
        return AllStudentPoints("");
    }

    public List<StudentPoints> GetStudentPointsByidStudent(int idStudent) {
        return AllStudentPoints("where idStudent = " + idStudent);
    }

    public StudentPoints GetStudentPointsByidLesson(int idlekcija) {
        return AllStudentPoints("where idlekcija = " + idlekcija).get(0);
    }

    public StudentPoints GetStudentPointsByMid(int semestar) {
        return AllStudentPoints("where semestar = " + semestar).get(0);
    }

    public StudentPoints GetStudentPointsByQuiz(int kviz) {
        return AllStudentPoints("where kviz = " + kviz).get(0);
    }

    public StudentPoints GetStudentPointsByActivity(int aktivnost) {
        return AllStudentPoints("where aktivnost = " + aktivnost).get(0);
    }

    public StudentPoints GetStudentPointsByFinal(int finalno) {
        return AllStudentPoints("where finalno = " + finalno).get(0);
    }

    public StudentPoints GetStudentPointsByTotal(int ukupno) {
        return AllStudentPoints("where ukupno = " + ukupno).get(0);
    }

    public StudentPoints GetStudentPointsByidStudentPoints(int idStudentBodovi) {
        return AllStudentPoints("where idStudentBodovi = " + idStudentBodovi).get(0);
    }

    //DELETE
    public void DelStudentLesson(int id) {
        try {
            String sql = "Delete from StudentLesson where idStudentLekcija = " + id;
            st.execute(sql);
        } catch (Exception e) {
            System.out.println("Error DelStudentLesson: " + e);
        }
    }

}
